<?php
session_start();
require_once("lib/fonctions.inc.php");
include("modele/class.pdoLafleur.inc.php");
include("vues/v_entete.php") ;
include("vues/v_bandeau.php") ;

if(!isset($_REQUEST['uc']))
     $uc = 'accueil';
else
	$uc = $_REQUEST['uc'];

$pdo = PdoLafleur::getPdoLafleur();	 
switch($uc)
{
	case 'accueil':
		{include("vues/v_accueil.php");break;}

	case 'voirProduits' :
		{include("controleurs/c_voirProduits.php");break;}

	case 'gererPanier' :
		{ include("controleurs/c_gestionPanier.php");break; }


	
	case 'GererTypeAchat' :
		{   
		include("controleurs/c_gestionTypeAchat.php");break; 
		}
	
    case 'ajout_utilisateur':
	{include("controleurs/c_gestionUtilisateur.php");break;}

	case 'administrer' :
	  { include("controleurs/c_gestionProduits.php");break;  }

case 'conexion':
{
	include ("vues/login.php");break;
}

case 'inscription':
{
	include ("vues/register.php");break;
}
}
?>

