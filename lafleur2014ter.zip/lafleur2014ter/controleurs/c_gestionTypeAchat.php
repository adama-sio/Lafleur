<?php
//  Xavier 2019-03-04

$action = $_REQUEST['action'];

switch($action)
{
	case 'AjouterTypeAchat':
	{
		$libelleachat =''; 
		$description =''; 
		include ("vues/v_TypeAchat_Creation.php");
	}	break;


	case 'EnregistrerTypeAchat'	:
	{
		$libelleachat =$_REQUEST['libelleachat'];
		$description =$_REQUEST['description'];
		$msgErreurs = getErreursSaisieTypeAchat($libelleachat,$description);
		if (count($msgErreurs)!=0)
		{
			include ("vues/v_erreurs.php");
			include ("vues/v_TypeAchat_Creation.php");
		}
		else
		{
			$pdo->creerTypeAchat($libelleachat,$description);			
			$message = "Nouveau type d'achat enregistré";
			include ("vues/v_message.php");
		}	break;
	}

	//  Xavier 2019-03-05
	case 'AfficherTypesAchat':
	{
		$lesTypesAchats = $pdo->getLesTypesAchats();
		include ("vues/v_TypeAchat_Afficher.php");		
		break;
	}	

	//  Xavier 2019-03-07
	case 'TypesAchatSupprimer':
	{
		$resultat="";
		$idasupprimer=$_REQUEST['id'];
		$Type_achat_libelle_a_supprimer =$_REQUEST['libelle'];
		$resultat = $pdo->TypeAchatSupprimer($idasupprimer);			
		$message = "Type achat ".$Type_achat_libelle_a_supprimer." supprimé de la base de données.";
		include ("vues/v_message.php");
		include ("vues/v_TypeAchat_Afficher.php");	
		break;
		
	}	
}
?>


