<?php

if($bdd = mysqli_connect('localhost', 'root', 'root', '01ppe2_lafleur2014ter'))

{
//Permet de résoudre les prolblèmes d'accents dans les pages Web
mysqli_query($bdd, "SET NAMES UTF8");
  // Si la connexion a réussi, rien ne se passe.

}

else

{
    echo 'Erreur de connexion à la base : '. mysqli_connect_error() . mysqli_connect_errno(); // On affiche un message d'erreur.

}

?>
