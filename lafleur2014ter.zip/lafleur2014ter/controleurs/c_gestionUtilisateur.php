<?php

//  Xavier 2019-03-04P


$action = $_REQUEST['action'];

switch($action)
{
	case 'AjouterUtilisateur':
	{ 
		$libelleUtilisateur =''; 
		$descriptions =''; 
		include ("vues/v_ajout_utilisateur.php");
	}	break;


	case 'EnregistrerUtilisateur'	:
	{
		$libelleUtilisateur =$_REQUEST['libelleUtilisateur'];
		$descriptions =$_REQUEST['description'];
		$msgErreurs = getErreursSaisieTypeUtilisateu(rH$libelleUtilisateur,$descriptions);
		if (count($msgErreurs)!=0)
		{
			include ("vues/v_erreurs.php");
			include ("vues/v_ajout_utilisateur.php");
		}
		else
		{
			$pdo->creerTypeUtilisateur($libelleUtilisateur,$descriptions);			
			$message = "Nouveau type d'achat enregistré";
			include ("vues/v_message.php");
		}	break;
	}

	//  Xavier 2019-03-05
	case 'AfficherUtilisateur()':
	{
		$lesUtilisateur = $pdo->getUtilisateur();
		include ("vues/v_TypeAchat_Afficher.php");		
		break;
	}	

	//  Xavier 2019-03-07
	case 'TypesAchatSupprimer':
	{
		$resultat="";
		$idasupprimer=$_REQUEST['id'];
		$Type_achat_libelle_a_supprimer =$_REQUEST['libelle'];
		$resultat = $pdo->TypeAchatSupprimer($idasupprimer);			
		$message = "Type achat ".$Type_achat_libelle_a_supprimer." supprimé de la base de données.";
		include ("vues/v_message.php");
		include ("vues/v_TypeAchat_Afficher.php");	
		break;
		
	}	
}
?>


