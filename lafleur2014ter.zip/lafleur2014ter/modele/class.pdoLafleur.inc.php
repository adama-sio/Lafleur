<?php
/** 
 * Classe d'accès aux données. 
 
 * Utilise les services de la classe PDO
 * pour l'application lafleur

 */

class PdoLafleur

{   		
      	private static $serveur='mysql:host=localhost';
      	private static $bdd='dbname=01ppe2_lafleur2014ter';   		
      	private static $user='root' ;    		
      	private static $mdp='root' ;	
		private static $monPdo;
		private static $monPdoLafleur = null;
/**
 * Constructeur privé, crée l'instance de PDO qui sera sollicitée
 * pour toutes les méthodes de la classe
 */				
	private function __construct()
	{
    		PdoLafleur::$monPdo = new PDO(PdoLafleur::$serveur.';'.PdoLafleur::$bdd, PdoLafleur::$user, PdoLafleur::$mdp); 
			PdoLafleur::$monPdo->query("SET CHARACTER SET utf8");
	}
	public function _destruct(){
		PdoLafleur::$monPdo = null;
	}


/**
 * Fonction statique qui crée l'unique instance de la classe
 *
 * Appel : $instancePdolafleur = PdoLafleur::getPdoLafleur();
 * @return l'unique objet de la classe PdoLafleur
 */
	public  static function getPdoLafleur()
	{
		if(PdoLafleur::$monPdoLafleur == null)
		{
			PdoLafleur::$monPdoLafleur= new PdoLafleur();
		}
		return PdoLafleur::$monPdoLafleur;  
	}


/**
 * Retourne toutes les catégories sous forme d'un tableau associatif
 *
 * @return le tableau associatif des catégories 
*/
	public function getLesCategories()
	{
		$req = "select * from categorie";
		$res = PdoLafleur::$monPdo->query($req);
		$lesLignes = $res->fetchAll();
		return $lesLignes;
	}

/**
 * Retourne sous forme d'un tableau associatif tous les produits de la
 * catégorie passée en argument
 * 
 * @param $idCategorie 
 * @return un tableau associatif  
*/

	public function getLesProduitsDeCategorie($idCategorie)
	{
	    $req="select * from produit where idCategorie = '$idCategorie'";
		$res = PdoLafleur::$monPdo->query($req);
		$lesLignes = $res->fetchAll();
		return $lesLignes; 
	}


/**
 * Retourne les produits concernés par le tableau des idProduits passée en argument
 *
 * @param $desIdProduit tableau d'idProduits
 * @return un tableau associatif 
*/
	public function getLesProduitsDuTableau($desIdProduit)
	{
		$nbProduits = count($desIdProduit);
		$lesProduits=array();
		if($nbProduits != 0)
		{
			foreach($desIdProduit as $unIdProduit)
			{
				$req = "select * from produit where id = '$unIdProduit'";
				$res = PdoLafleur::$monPdo->query($req);
				$unProduit = $res->fetch();
				$lesProduits[] = $unProduit;
			}
		}
		return $lesProduits;
	}


/**
 * Crée une commande 
 *
 * Crée une commande à partir des arguments validés passés en paramètre, l'identifiant est
 * construit à partir du maximum existant ; crée les lignes de commandes dans la table contenir à partir du
 * tableau d'idProduit passé en paramètre
 * @param $nom 
 * @param $rue
 * @param $cp
 * @param $ville
 * @param $mail
 * @param $lesIdProduit
 
*/
	public function creerCommande($nom,$rue,$cp,$ville,$mail, $lesIdProduit )
	{
		$req = "select max(id) as maxi from commande";
	/*	echo $req."<br>"; */
		$res = PdoLafleur::$monPdo->query($req);
		$laLigne = $res->fetch();
		$maxi = $laLigne['maxi'] ;
		$maxi++;
		$idCommande = $maxi;
	/*	echo $idCommande."<br>"; */
	/*	echo $maxi."<br>";    */
		$date = date('Y/m/d');
		$req = "insert into commande values ('$idCommande','$date','$nom','$rue','$cp','$ville','$mail')";
	/*	echo $req."<br>";  */
		$res = PdoLafleur::$monPdo->exec($req);

		foreach($lesIdProduit as $unIdProduit)
		{
			$req = "insert into contenir values ('$idCommande','$unIdProduit')";
			/*echo $req."<br>"; */
			$res = PdoLafleur::$monPdo->exec($req);
		}
	}


	
/**
 * Crée un type d'achat' à partir du masque Type achat - Xavier 2019-03-04
 * @param $libellé
 *  
*/
	public function creerTypeAchat($libelle,$description)
	{
		$req = "select max(id) as maxi from typeachat";
		$res = PdoLafleur::$monPdo->query($req);
		$laLigne = $res->fetch();
		$maxi = $laLigne['maxi'] ;
		$maxi++;
		$idTypeAchat = $maxi;
		$req = "insert into typeachat values ('$idTypeAchat','$libelle','$description')";
		$res = PdoLafleur::$monPdo->exec($req);
	}

    public function creerTypeUtilisateur($libelleUtilisateur,$descriptions)
    {
	    $req = "select max(id) as maxi from utilisateur";
		$res = PdoLafleur::$monPdo->query($req);
		$laLigne = $res->fetch();
		$maxi = $laLigne['maxi'] ;
		$maxi++;
		$id = $maxi;
		$req = "insert into utilisateur values ('$idUtilisateur','$libelleUtilisateur','$descriptions')";
		$res = PdoLafleur::$monPdo->exec($req);
	}

//  Xavier 2019-03-05
		/**
	 * Retourne tous les types d'achats enregistrés
	 *
	 * @return le tableau associatif des types d'achat
	*/
	public function getLesTypesAchats()
	{
		$req = "select * from typeachat";
		$res = PdoLafleur::$monPdo->query($req);
		$lesLignes = $res->fetchAll();
		return $lesLignes;
	}

	public function getUtilisateur()
	{
		$req = "select * from utilisateur";
		$res = PdoLafleur::$monPdo->query($req);
		$lesLigne = $res->fetchAll();
		return $lesLigne;
	}

//  Xavier 2019-03-07
		/**
	 * Supprime un type d'achat de la base de données
	 *
	 * @return le nom du type d'activité qui a été supprimé
	*/
	public function TypeAchatSupprimer($id_TypeAchatASupprimer)
	{
		$req = "delete FROM typeachat WHERE id = '$id_TypeAchatASupprimer'";
	/*	$res = PdoLafleur::$monPdo->query($req);  */
		$res = PdoLafleur::$monPdo->exec($req);
	
	}



	
}


?>