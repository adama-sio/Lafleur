<div id="listetypeachat">
  <!-- Xavier 2019-03-05 -->
	<table>
			<tr>
					<th> id </th>
					<th> libellé </th>
					<th> description </th>
			</tr>

	<?php
		foreach( $lesUtilisateurs as $Utilisateur) 
		{
			$idUser = $Utilisateur['idUser'];
			$libelleUser = $Utilisateur['libelleUser'];
			$descriptionUser = $Utilisateur['descriptionUser'];
			?>
			<tr>
					<th><?php echo $idUser; ?></th>
					<th><?php echo $libelleUser; ?></th>
					<th><?php echo $descriptionUser; ?></th>					
			</tr>
		<?php
		}
	?>
	</table>
</div>
