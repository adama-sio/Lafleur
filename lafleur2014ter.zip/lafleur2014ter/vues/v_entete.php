<!DOCTYPE HTML >
<!-- TITRE ET MENUS -->
<html lang="fr">
    <head>
            <title>Lafleur 2014-Ter</title>
            <meta http-equiv="Content-Language" content="fr">
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <link href="styles/cssGeneral.css" rel="stylesheet" type="text/css">
    </head>
<body >