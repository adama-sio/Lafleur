<div id="TypeAchat_Masque_Creation">
<form method="POST" action="index.php?uc=GererTypeAchat&action=EnregistrerTypeAchat">
   <fieldset id="TypeAchat_Masque">
     <legend class="MasqueFieldSet_Titre"> Type Achat </legend>
        <p>
            <label >Libellé *</label>
            <input id="libelleachat_id" type="text" name="libelleachat" value="<?php echo $libelleachat ?>" size="30" maxlength="45">
        </p>
        <p>
             <label >Description *</label>
             <input id="description_id" type="text" name="description" value="<?php echo $description ?>" size="30" maxlength="45">
        </p>
        <p>
            <input type="submit" value="Valider" name="valider">
           <input type="reset" value="Annuler" name="annuler"> 
        </p>
    </fieldset>
</form>
</div>





