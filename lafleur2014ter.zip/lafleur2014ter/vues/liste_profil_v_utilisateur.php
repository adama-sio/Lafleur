<div id="listetypeachat">
  <!-- Xavier 2019-03-05 -->
	<table>
			<tr>
					<th> id </th>
					<th> libellé </th>
					<th> description </th>
			</tr>

	<?php
		foreach( $lesUtilisateur as $unUtilisateur) 
		{
			$id = $unUtilisateur['id'];
			$libelle = $unUtilisateur['Libelle'];
			$description = $unUtilisateur['description'];
			?>
			<tr>
					<th><?php echo $id; ?></th>
					<th><?php echo $libelle; ?></th>
					<th><?php echo $description; ?></th>					
			</tr>
		<?php
		}
	?>
	</table>
</div> 