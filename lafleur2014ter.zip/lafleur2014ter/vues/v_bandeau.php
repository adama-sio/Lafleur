<div id="bandeau">
<!--<img src="images/menuGauche.gif"	alt="Choisir" title="Choisir"/>-->
		<img src="images/agence.png" height="500px" width="900px" alt="Lafleur" title="Lafleur"/>
</div>
<!--  Menu haut-->
<ul id="menu">
	<li><a href="index.php?uc=accueil"> Accueil </a></li>
	<li><a href="index.php?uc=voirProduits&action=voirCategories"> Catalogue </a></li>
	<li><a href="index.php?uc=gererPanier&action=voirPanier"> Panier </a></li>
	<li><a href="index.php?uc=GererTypeAchat&action=AjouterTypeAchat"> Type d'achat - Ajouter </a></li>
	<li><a href="index.php?uc=GererTypeAchat&action=AfficherTypesAchat">Type d'achat - Lister </a></li>
    <li><a href="index.php?uc=ajout_utilisateur&action=AjouterUtilisateur ">  Billet d’avion </a></li>
 <li><a href="index.php?uc=liste_utilisateur&action=AfficherUtilisateur">Séjour à Hotel </a></li>
 
<li><a href="index.php?uc=conexion">inscription </a> <a href="login.php">connexion </a> </li>


</ul>
