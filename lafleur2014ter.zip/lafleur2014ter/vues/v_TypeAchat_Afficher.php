<div id="listetypeachat">
  <!-- Xavier 2019-03-05 -->
	<table>
			<tr>
					<th> id </th>
					<th> libellé </th>
					<th> description </th>
			</tr>

	<?php
		foreach( $lesTypesUtilisateur as $unTypeUtilisateur) 
		{
			$id = $unTypeUtilisateur['id'];
			$libelle = $unTypeUtilisateur['Libelle'];
			$descriptions = $unTypeUtilisateur['descriptions'];
			?>
			<tr>
					<th><?php echo $id; ?></th>
					<th><?php echo $libelle; ?></th>
					<th><?php echo $description; ?></th>					
			</tr>
		<?php
		}
	?>
	</table>
</div>
