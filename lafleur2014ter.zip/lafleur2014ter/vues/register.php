<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../style.css">
    <title>Atelier</title>
</head>

<body>

     <?php require('../connexion_base.php');
    ?>

<div class="container" style="background:rgba(0,0,0,0.35); border-radius: 20px; margin-top:10%; margin-left: 15%;margin-right: 15%; text-align:center;">


      <h1>Inscription</h1>

<?php
      // Si le tableau register-form existe alors le formulaire a été envoyé
     if(isset($_POST['submit']))  //Post car on veut envoyer la valeur & isset ?
     {
       $username =htmlentities(trim($_POST['username']));  //htmlentities(trim(post...)) sert a enlever tout les espaces ainsi que les symboles dans les cookies reperable en js pour eviter de ce faire hacker
       $password =htmlentities(trim($_POST['password']));
       $repeatpassword =htmlentities(trim($_POST['repeatpassword']));
         if($username&&$password&&$repeatpassword)
         {
           if($password==$repeatpassword)
           {
             $password=md5($password);
             $connect= mysqli_connect('localhost','root','root') or die ('Error'); 
             mysqli_select_db($connect,'01ppe2_lafleur2014ter');
           $log = mysqli_query($connect,"SELECT * FROM user WHERE username = '$username'"); //reg pour registre, (bibliotheque pour ne pas répéter l'username)
             $rows = mysqli_num_rows($log);

             if($rows==0)
             {
             $query =mysqli_query($connect,"INSERT INTO user VALUES('','$username','$password')");
             die("Inscription términée,<a href='login.php'> Connectez vous</a>"); //or die(mysql_error()) sert a art la suite du code si il rencontre un pb, ici avc la bdd
             }else echo "Ce pseudo n'est pas disponible";

         }else echo "Les mots de passes doivent être identiques";

       }else echo "Veuillez saisir tout les champs";


     }
     ?>


    <form method="post" action="register.php">
        <label>Pseudo
          <input name="username" type="text">
        </label>
        <br><br>

        <label>Mot de passe
            <input name="password" type="password">
        </label>
        <br><br>

        <label>Confirmation du mot de passe
            <input name="repeatpassword" type="password">
        </label>
        <br><br>

        <button type="submit" value="S'inscrire" name="submit">S'inscrire</button>
    </form>


    <a href="login.php">Connexion</a>
</div>
</body>

</html>
