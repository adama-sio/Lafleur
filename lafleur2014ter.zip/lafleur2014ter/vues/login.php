<!DOCTYPE html>
<html >

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../style.css">
    <title>Atelier</title>
</head>

<body>

    <form method="post" action="login.php">
        <label>Pseudo
          <input name="username" type="text">
        </label>
        <br><br>

        <label>Mot de passe
            <input name="password" type="password">
        </label>
        <br><br>

        <button type="submit" value="Connexion" name="submit">Connexion</button>
    </form>

    <?php require('controleurs/connexion_base.php');// Appelle de la connexion à la BDD
    session_start();




?>

<div class="container" style="background:rgba(0,0,0,0.35); border-radius: 20px; margin-top:10%; margin-left: 15%;margin-right: 15%; text-align:center;">

    <h1>Connexion</h1>
<?php

    if(isset($_POST['submit']))
    {
      $username =htmlentities(trim($_POST['username']));
      $password =htmlentities(trim($_POST['password']));

        if($username && $password)
        {
          $password=md5($password);
          $connect= mysqli_connect('localhost','root','root') or die ('Error'); //si la connection est raté il arrete tout le code
          mysqli_select_db($connect,'01ppe2_lafleur2014ter');

          $log = mysqli_query($connect,"SELECT*FROM user WHERE username='$username'AND password='$password'");
          $rows =mysqli_num_rows($log);
          if($rows==1)
          {
            session_start();
            $_SESSION['login'] = $username;
            header('Location:../Accueil.php');
          }else echo "Pseudo ou mot de passe incorrect";
        }else echo "Veuillez saisir tout les champs";

    }
?>

    <form method="post" action="login.php">
        <label>Pseudo
          <input name="username" type="text">
        </label>
        <br><br>

        <label>Mot de passe
            <input name="password" type="password">
        </label>
        <br><br>

        <button type="submit" value="Connexion" name="submit">Connexion</button>
    </form>


    <a href="register.php">Inscription</a>

  </div>
</body>

</html>
