<div id="TypeAchat_Masque_Creation">
<form method="POST" action="index.php?uc=GererUtilisateur&action=EnregistrerUtilisateur">
   <fieldset id="TypeAchat_Masque">
     <legend class="MasqueFieldSet_Titre"> Utilisateur </legend>
        <p>
            <label >Libellé *</label>
            <input id="libelleUser_id" type="text" name="libelleUser" value="<?php echo $libelleUser ?>" size="30" maxlength="45">
        </p>
        <p>
             <label >Description *</label>
             <input id="descriptionUser_id" type="text" name="descriptionUser" value="<?php echo $descriptionUser ?>" size="30" maxlength="45">
        </p>
        
        <p>
            <input type="submit" value="Valider" name="valider">
           <input type="reset" value="Annuler" name="annuler"> 
        </p>
    </fieldset>
</form>
</div>

